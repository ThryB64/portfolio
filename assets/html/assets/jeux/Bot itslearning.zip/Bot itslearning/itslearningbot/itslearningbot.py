from selenium import webdriver
import time

class lazybot() :
    def __init__(self) : 
        self.driver = webdriver.Chrome(executable_path="C:\web_drivers\chromedriver.exe") #instance de webdriver en global.

    def login(self) :
        self.driver.get('https://ecnad.itslearning.com/index.aspx?Username=&RedirectLogin=www.itslearning.com')
        link_btn=self.driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_nativeLoginLinkContainer"]/a')
        link_btn.click()
        #fill les infos 
        username = self.driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_Username_input"]')
        username.send_keys('tberard')
        password = self.driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_Password_input"]')
        password.send_keys('}UTNth#y')
        log_btn = self.driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_nativeLoginButton"]')
        log_btn.click()

    def navigate(self) :
        accueil= self.driver.find_element_by_xpath('//*[@id="ctl00_CommonMenuRow"]/nav[1]/ul/li[1]/a/span')
        accueil.click()
        self.driver.get('https://ecnad.itslearning.com/ContentArea/ContentArea.aspx?LocationID=5570&LocationType=1')
        #boucle de 200s
        while(1):
            ressource= self.driver.find_element_by_xpath('//*[@id="link-resources"]')
            ressource.click()
            time.sleep(5)
            ensemble= self.driver.find_element_by_xpath('//*[@id="link-dashboard"]')
            ensemble.click()
            time.sleep(5)


bot=lazybot()
bot.login()
bot.navigate()


